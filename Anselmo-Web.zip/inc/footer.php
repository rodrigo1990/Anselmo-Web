<footer>	
<div class="row">
	<div class="container">
		<ul class="flex">
			<li> <img src="img/iso.png" alt="" class="iso"> </li>
			<li><p><i class="fab fa-instagram"></i> @anselmohotel</p></li>
			<li><p><i class="fab fa-facebook-f"></i> /anselmohotel</p></li>
			<li><p><i class="fas fa-phone"></i> +54 9 11 4834-3200</p></li>
			<li><div class="left"><i class="fas fa-map-marker-alt"></i></div><div class="left"><p><b>Don Anselmo Aieta 1096</b><br>San Telmo - Buenos Aires, Argentina.</p></div></li>


		</ul>
	
	</div>
</div>
</footer>
<script type="text/javascript" src="js/JQuery.min.js"></script>
<script type="text/javascript" src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/animacionesHeader.js"></script>